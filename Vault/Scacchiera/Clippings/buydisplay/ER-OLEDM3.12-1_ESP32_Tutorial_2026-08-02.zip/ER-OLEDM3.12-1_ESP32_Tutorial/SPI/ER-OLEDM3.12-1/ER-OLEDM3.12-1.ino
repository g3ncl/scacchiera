/***************************************************
//Web: http://www.buydisplay.com
EastRising Technology Co.,LTD
Examples for ER-OLEDM3.12-1
Display is Hardward SPI 4-Wire SPI Interface 
Tested and worked with:
Works with Arduino 2.3.4 IDE  
NOTE: test OK:ESP32-WROOM-32 
****************************************************/
 
/*
  == Hardware connection ==
    OLED   =>    Arduino
  *1. VDD    ->    3.3
  *2,3,7,8,12-16. GND   ->    GND
  *4. RES    ->    8  
  *5. CS     ->    10
  *6. DC     ->    9 
  *9. SCL    ->    SCK
  *10. SDI    ->    MOSI
*/


#include <SPI.h>
#include "er_oled.h"

//uint8_t oled_buf[OLED_Y_MAXPIXEL * OLED_X_MAXPIXEL/2];

void setup() {
  Serial.begin(9600);
  Serial.print("OLED Example\n");

  /* display an image of bitmap matrix */
  er_oled_begin();

  
}

void loop() {
  
  

 // er_oled_Fill(0,0,256,64,0);
 
  DrawBMP(0,0,256,64,pic0,1); //x:0,y:0,col:128,row:96 	reverse color:no         gray              
  delay(3000); 


  DrawBMP(0,0,256,64,pic1,1); //x:0,y:0,col:128,row:96 	reverse color:yes 	  gray 
  delay(3000); 

  DrawSingleBMP(0,0,256,64,pic2,0); //x:0,y:0,col:128,row:96 	reverse color:no 	  monochrome
  delay(3000); 

   
  DrawSingleBMP(0,0,256,64,pic3,0); //x:0,y:0,col:128,row:96 	reverse color:no	  monochrome 
  delay(3000); 



  er_oled_Fill(0,0,256,64,0x00);
  er_oled_string(0, 0, "********************************",0);  
  er_oled_string(32, 16, "EastRising Technology",  0); 
  er_oled_string(40, 32, "www.buydisplay.com",  1); 
  er_oled_string(0, 48, "********************************",0); 
  uint8_t i;
  for(i=0;i<=48;i++)
  {
  command(0xa1); //start line
  command(i);
  delay(100);
  }
   for(i=48;i>0;i--)
  {
  command(0xa1); //start line
  command(i);
  delay(100);
  }
    delay(1000);
   command(0xa1); //start line
  command(0); 
  
}


