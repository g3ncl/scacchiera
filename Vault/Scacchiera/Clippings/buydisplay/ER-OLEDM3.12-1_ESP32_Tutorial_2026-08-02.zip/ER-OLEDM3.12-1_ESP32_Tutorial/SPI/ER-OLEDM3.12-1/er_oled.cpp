/***************************************************
//Web: http://www.buydisplay.com
EastRising Technology Co.,LTD
****************************************************/
#include <SPI.h>
#include "er_oled.h"

void command(uint8_t cmd)
{
  digitalWrite(OLED_DC, LOW);
  digitalWrite(OLED_CS, LOW);
  SPI.transfer(cmd);
  digitalWrite(OLED_CS, HIGH);
}

void data(uint8_t dat)
{
  digitalWrite(OLED_DC, HIGH);
  digitalWrite(OLED_CS, LOW );
  SPI.transfer(dat);
  digitalWrite(OLED_CS, HIGH);
}

void er_oled_begin()
{

    pinMode(OLED_RST, OUTPUT);
    pinMode(OLED_DC, OUTPUT);
    pinMode(OLED_CS, OUTPUT);
    SPI.begin();
    
      SPI.beginTransaction(SPISettings(20000000, MSBFIRST, SPI_MODE0)); 
    
    digitalWrite(OLED_CS, LOW);
    digitalWrite(OLED_RST, HIGH);
    delay(10);
    digitalWrite(OLED_RST, LOW);
    delay(10);
    digitalWrite(OLED_RST, HIGH);
    delay(100);
 
   	command(0xFD);
	command(0x12);
	
	command(0xAE);
	
	command(0x15);
	command(0X00); //Start column Address
	command(0X7F); //End column Address
	
	command(0X75); //Set Row Address
	command(0X00); //Start Row Address
	command(0X3F); //End Row Address
	
	command(0X81); //Set contrast
	command(0X80);
	
        command(0xA0);  // Set Re-map
        command(0X52);	//Rotate 180 degrees:  0xC3

	command(0XA1); //Set Display Start Line
	command(0X00);
	
	command(0XA2); //Set Display Offset
	command(0X00);
	
	command(0XA4); //Normal Display
	
	command(0XA8); //Set Multiplex Ratio
	command(0X3F);
	
	command(0XAB); //Set VDD regulator
	command(0X01); //Regulator Enable
	
	command(0XAD); //External /Internal IREF Selection
	command(0X02);
	
	command(0XB1); //Set Phase Length
	command(0X22);
	
	command(0XB3); //Display clock Divider
	command(0XA0);
	
	command(0XB6); //Set Second precharge Period
	command(0X04);
	
	command(0XB9); //Set Linear LUT
	
	command(0XBc); //Set pre-charge voltage level
	command(0X1F); //0.5*Vcc
	
	command(0XBD); //Pre-charge voltage capacitor Selection
	command(0X01);
	
	command(0XBE); //Set cOM deselect voltage level
	command(0X05); //0.82*Vcc
	
	
	command(0XAF); //Display ON

     
    delay(10);
}


void Column_Address(uint8_t a,uint8_t b)
{
 
    command(0x15);      // Set Column Address
    command(a);
    command(b);
}

void Row_Address(uint8_t a,uint8_t b)
{
    command(0x75);      // Row  Address
    command(a);
    command(b);
}


void er_oled_Fill(uint16_t x1,uint8_t y1,uint16_t x2,uint8_t y2,uint8_t color)
{
    uint8_t j,i;
    x1/=2;
    x2/=2;
    Column_Address(x1,x2-1);
    Row_Address(y1,y2-1);
    for(i=y1;i<y2;i++)
    {
        for(j=x1;j<x2;j++)
        {
           data(color);
        }
    }
}


void Data_processing(uint8_t temp)  //turns 1byte B/W data to 4 bye gray data  with 8 Pixel
{uint8_t temp1,temp2;

  if(temp&0x80)temp1=0xf0;
  else temp1=0x00;
  if(temp&0x40)temp2=0x0f;
  else temp2=0x00;
  temp1=temp1|temp2;
  data(temp1); //Pixel1,Pixel2
  if(temp&0x20)temp1=0xf0;
  else temp1=0x00;
  if(temp&0x10)temp2=0x0f;
  else temp2=0x00;
  temp1=temp1|temp2;
  data(temp1);  //Pixel3,Pixel4                
  if(temp&0x08)temp1=0xf0;
  else temp1=0x00;
  if(temp&0x04)temp2=0x0f;
  else temp2=0x00;
  temp1=temp1|temp2;
  data(temp1);  //Pixel5,Pixel6               
  if(temp&0x02)temp1=0xf0;
  else temp1=0x00;
  if(temp&0x01)temp2=0x0f;
  else temp2=0x00;
  temp1=temp1|temp2;
  data(temp1);  //Pixel7,Pixel8               
}


void er_oled_char(uint16_t x, uint8_t y, const char  *acsii, uint8_t mode)
{ uint8_t i,str;uint16_t OffSet;
  x=x/2;
  OffSet = (*acsii - 32)*16;
  Column_Address(x,x+3);
  Row_Address(y, y+15);
  for (i=0;i<16;i++)
  {     str =pgm_read_byte(&AsciiLib[OffSet + i]);  
        if(mode) str=~str;
         Data_processing (str);             
  }
}

void er_oled_string(uint16_t x, uint8_t y, const char *pString,  uint8_t Mode)
{     
  while(1)
  {
        if (*pString == 0)
        {
            return;
        }
            er_oled_char(x, y, pString,Mode);
            x += 8;
            pString += 1;              
  }   
}





void DrawBMP(uint16_t x,uint8_t y,uint16_t length,uint8_t width,const uint8_t * pBuf,uint8_t mode)
{
    uint16_t i,num;
    length=(length/2+((length%2)?1:0))*2;
    num=length/2*width;
    x/=2;
    length/=2;
    Column_Address(x,x+length-1);
    Row_Address(y,y+width-1);
    for(i=0;i<num;i++)
    {
        if(mode)
        {
            data(~pgm_read_byte(pBuf));
        }
        else
        {
            data(pgm_read_byte(pBuf));
        }
       *pBuf++;
    }
}





void DrawSingleBMP(uint16_t x,uint8_t y,uint16_t length,uint8_t width,const uint8_t * pBuf,uint8_t mode)
{
    uint8_t k,DATA0,DATA=0;
    uint16_t i,num;
    length=(length/8+((length%8)?1:0))*8;
    num=length*width/8;
    x/=2;
    length/=2;
    Column_Address(x,x+length-1);
    Row_Address(y,y+width-1);
    for(i=0;i<num;i++)
    {
        for(k=0;k<4;k++)
        {  DATA0=(pgm_read_byte(pBuf));
            if(DATA0&(0x80>>(k*2+0)))
            {
                DATA=0xf0;
            }
            if(DATA0&(0x80>>(k*2+1)))
            {
                DATA|=0x0f;
            }
            if(mode)
            {
               data(~DATA);
            }
            else
            { 
                data(DATA);
            }
            DATA=0;
        }
        *pBuf++; 
        
    }
}


